package rags;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;  
import java.util.ArrayList;

public class ToDoListApp {
    private List<Task> tasks;
    private List<User> users;
    private User currentUser;

    private JFrame frame;
    private JPanel taskPanel;
    private JButton addButton;
    private JButton saveButton;
    private JButton loadButton;
    private JPanel loginPanel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton createAccountButton;

    private static final Color COMPLETED_COLOR = new Color(90, 90, 90);
    private static final Font TASK_FONT = new Font("Arial", Font.PLAIN, 16);
    private static final String FILE_PATH = "tasks.txt";
    private static final String USERS_FILE_PATH = "users.txt";

    public ToDoListApp() {
        tasks = new ArrayList<>();
        users = new ArrayList<>();
        initializeUsers();
        initializeGUI();
    }

    private void initializeUsers() {
        // Load users from file or initialize default users
        try (BufferedReader reader = new BufferedReader(new FileReader(USERS_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 2) {
                    String username = parts[0];
                    String password = parts[1];
                    users.add(new User(username, password));
                }
            }
        } catch (IOException e) {
            // Initialize default users
            users.add(new User("user1", "password1"));
            users.add(new User("user2", "password2"));
        }
    }

    private void initializeGUI() {
        frame = new JFrame("To-Do List App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(new Color(240, 240, 240));

        loginPanel = new JPanel();
        loginPanel.setLayout(new GridLayout(4, 2, 10, 10));
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("Login");
        createAccountButton = new JButton("Create Account");
        initializeLoginPanel();

        frame.add(loginPanel, BorderLayout.CENTER);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (login(username, password)) {
                    showTaskPanel();
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        createAccountButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showCreateAccountPanel();
            }
        });

        frame.pack();
        frame.setLocationRelativeTo(null); // Center the frame on screen
        frame.setVisible(true);
    }

    private void initializeLoginPanel() {
        loginPanel.removeAll();
        loginPanel.add(new JLabel("Username:"));
        loginPanel.add(usernameField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passwordField);
        loginPanel.add(loginButton);
        loginPanel.add(createAccountButton);
        loginPanel.revalidate();
        loginPanel.repaint();
    }

    private void showCreateAccountPanel() {
        String newUsername = JOptionPane.showInputDialog(frame, "Enter new username:");
        String newPassword = JOptionPane.showInputDialog(frame, "Enter new password:");

        if (newUsername != null && newPassword != null) {
            users.add(new User(newUsername, newPassword));
            JOptionPane.showMessageDialog(frame, "Account created successfully.", "Account Created", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private boolean login(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.isPasswordCorrect(password)) {
                currentUser = user;
                return true;
            }
        }
        return false;
    }

    private void showTaskPanel() {
        frame.remove(loginPanel);

        taskPanel = new JPanel();
        taskPanel.setLayout(new BoxLayout(taskPanel, BoxLayout.Y_AXIS));
        frame.add(new JScrollPane(taskPanel), BorderLayout.CENTER);

        addButton = new JButton("Add Task");
        saveButton = new JButton("Save");
        loadButton = new JButton("Load");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(addButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(loadButton);
        frame.add(buttonPanel, BorderLayout.NORTH);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addTask();
            }
        });

        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveTasksToFile();
            }
        });

        loadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadTasksFromFile();
            }
        });

        frame.revalidate();
        frame.repaint();
    }

    private void addTask() {
        String description = JOptionPane.showInputDialog(frame, "Enter task description:");
        if (description != null && !description.isEmpty()) {
            tasks.add(new Task(description));
            updateTaskPanel();
        }
    }

    private void updateTaskPanel() {
        taskPanel.removeAll();

        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);
            JPanel taskBox = createTaskBox(task, i);
            taskPanel.add(taskBox);
            taskPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        }

        taskPanel.revalidate();
        taskPanel.repaint();
    }

    private JPanel createTaskBox(Task task, int index) {
        JPanel taskBox = new JPanel();
        taskBox.setLayout(new BorderLayout());
        taskBox.setBorder(new CompoundBorder(new EmptyBorder(10, 10, 10, 10), new LineBorder(Color.BLACK)));
        taskBox.setBackground(task.isCompleted() ? COMPLETED_COLOR : Color.WHITE);

        JTextArea taskText = new JTextArea(task.toString());
        taskText.setFont(TASK_FONT);
        taskText.setEditable(false);
        taskText.setWrapStyleWord(true);
        taskText.setLineWrap(true);
        taskBox.add(taskText, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton editButton = new JButton("Edit");
        JButton deleteButton = new JButton("Delete");

        editButton.addActionListener(e -> editTask(index));
        deleteButton.addActionListener(e -> deleteTask(index));

        buttonsPanel.add(editButton);
        buttonsPanel.add(deleteButton);

        taskBox.add(buttonsPanel, BorderLayout.SOUTH);

        return taskBox;
    }

    private void saveTasksToFile() {
        try (PrintWriter writer = new PrintWriter(FILE_PATH)) {
            for (Task task : tasks) {
                writer.println(task.getDescription());
            }
            writer.close();
            JOptionPane.showMessageDialog(frame, "Tasks saved successfully.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error saving tasks.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadTasksFromFile() {
        tasks.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                tasks.add(new Task(line));
            }
            updateTaskPanel();
            JOptionPane.showMessageDialog(frame, "Tasks loaded successfully.");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error loading tasks.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editTask(int index) {
        Task task = tasks.get(index);
        String newDescription = JOptionPane.showInputDialog(frame, "Enter new task description:", task.getDescription());

        if (newDescription != null && !newDescription.isEmpty()) {
            task.setDescription(newDescription);
            updateTaskPanel();
        }
    }

    private void deleteTask(int index) {
        tasks.remove(index);
        updateTaskPanel();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ToDoListApp());
        
          String url = "jdbc:mysql://localhost:3306/your_database";
        String username = "your_username";
        String password = "your_password";

        try {
           
            Connection connection = DriverManager.getConnection(url, username, password);

            
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


